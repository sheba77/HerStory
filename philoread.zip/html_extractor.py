from bs4 import BeautifulSoup
import os
import json


#find all html file names
path = r"bigData\html"

files = []
# r=root, d=directories, f = files
for r, d, f in os.walk(path):
    for file in f:
        if '.html' in file:
            files.append(os.path.join(r, file))
print(files)

#
for file_path in files:
    try:
        data = open(file_path, "r", encoding='utf-8').read()
        soup = BeautifulSoup(data, 'html.parser')
        print(file_path)

        book_name = soup.select("h1#bookTitle")[-1].text.strip()
        author_name = soup.select("div.bookAuthorProfile__name")[0].text.strip()
        book_data = soup.select("div#description>span")[-1].text
        author_data = '' if len(soup.select("div.bookAuthorProfile__about>span")) == 0 else \
            soup.select("div.bookAuthorProfile__about>span")[-1].text

        my_dict = {"book name": book_name, "author name": author_name, "book data": book_data, "author data": author_data}
        with open(r"bigData\data\{0}.json".format(book_name).replace("(", '').replace(")", '').
                          replace("/", "-").replace(":", "-").replace("?", '').replace(",", ''),
                  "w") as write_file:
            json.dump(my_dict,write_file)
    except:
        print("error in file_path", file_path)