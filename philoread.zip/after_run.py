from tkinter import *
import webbrowser
import re



def OpenUrl(name):
    f = open(r"bigData\linksforall.txt", "r")
    not_here = True
    for URL in f:
        first_part_of_name = name.split(':')[0]
        url_suffix = URL[:-1].replace("https://www.goodreads.com/book/show/", '')
        if re.sub('[^a-zA-Z]+', '', url_suffix).lower()== re.sub('[^a-zA-Z]+', '', first_part_of_name).lower():
            print(URL)
            webbrowser.open_new(URL)
            not_here = False
    if not_here:
        g = open(r"bigData\introductionLinks.txt", "r")
        for URL in g:
            first_part_of_name = name.split(':')[0]
            url_suffix = URL[:-1].replace("https://www.goodreads.com/book/show/", '')
            if re.sub('[^a-zA-Z]+', '', url_suffix).lower() == re.sub('[^a-zA-Z]+', '', first_part_of_name).lower():
                print(URL)
                webbrowser.open_new(URL)


def present_results(book_name_list):
    root = Tk()
    photo1 = PhotoImage(file=r"background+photo\paper.gif")
    w = photo1.width()
    h = photo1.height()
    root.resizable(width=False, height=False)
    background_lable = Label(root, image=photo1)
    background_lable.place(x=0, y=0, relwidth=1, relheight=1)

    lable = Label(root,text="Books you should read:", font=('times', 20, 'italic'))
    lable.pack()

    for item in book_name_list:
        # when we press we are taken to web page
        button = Button(root, text=item, height=2, width=60, font=('times', 12, 'italic'),
                        command=lambda x=item: OpenUrl(x))
        button.place(relx=1, rely=1)
        button.pack()





    root.title('Results')
    root.geometry("%dx%d+0+0" % (w/2, h))
    root.iconbitmap('book.ico')
    root.mainloop()


