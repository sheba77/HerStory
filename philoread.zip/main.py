from tkinter import *
import re
from network_x_graph import find_syllabus
from network_x_graph import load_func
from after_run import present_results

window = Tk()



class AutocompleteEntry(Entry):
    def __init__(self, lista, *args, **kwargs):

        Entry.__init__(self, *args, **kwargs)
        self.var = self["textvariable"]
        if self.var == '':
            self.var = self["textvariable"] = StringVar()
            self.var.set("Which book would you like to read? ")
            self.lista = lista

        self.var.trace('w', self.changed)
        self.bind("<Right>", self.selection)
        self.bind("<Up>", self.up)
        self.bind("<Down>", self.down)

        self.lb_up = False

    def changed(self, name, index, mode):
        words = self.comparison()
        if words:
            if not self.lb_up:
                self.lb = Listbox(font=('times', 12, 'italic'), name='lb')
                self.lb.bind("<Double-Button-1>", self.selection)
                self.lb.bind("<Return>", self.selection)
                self.lb.bind("<Right>", self.selection)
                self.lb.place(x=self.winfo_x(), y=self.winfo_y() + self.winfo_height(), width=550)
                self.lb_up = True

            self.lb.delete(0, END)
            for w in words:
                self.lb.insert(END, w)
        else:
            if self.lb_up:
                self.lb.destroy()
                self.lb_up = False

    def selection(self, event):
        if self.lb_up:
            self.var.set(self.lb.get(ACTIVE))
            self.lb.destroy()
            self.lb_up = False
            self.icursor(END)
            self.my_book = self.get()
            my_list = find_syllabus(self.my_book)
            window.destroy()
            present_results(my_list)


    def up(self, event):
        if self.lb_up:
            if self.lb.curselection() == ():
                index = '0'
            else:
                index = self.lb.curselection()[0]
            if index != '0':
                self.lb.selection_clear(first=index)
                index = str(int(index) - 1)
                self.lb.selection_set(first=index)
                self.lb.activate(index)

    def down(self, event):
        if self.lb_up:
            if self.lb.curselection() == ():
                index = '0'
            else:
                index = self.lb.curselection()[0]
            if index != END:
                self.lb.selection_clear(first=index)
                index = str(int(index) + 1)
                self.lb.selection_set(first=index)
                self.lb.activate(index)

    def comparison(self):
        pattern = re.compile('.*' + self.var.get() + '.*')
        return [w for w in self.lista if re.match(pattern, w)]


if __name__ == '__main__':
    # get path and create board
    path = r"bigData\data"
    photo1 = PhotoImage(file=r"background+photo\openbooks.gif")

    w = photo1.width()
    h = 700

    window.resizable(width=False, height=False)

    window.geometry("%dx%d+0+0" % (w, h))
    window.title("PhiloRead")

    background_lable = Label(window, image=photo1)
    background_lable.place(x=0, y=0, relwidth=1, relheight=1)

    # read from json the graph already created from books
    lista = load_func().nodes

    # auto complete for choosing book
    entry1 = AutocompleteEntry(lista, window, font=('times', 22, 'italic'))
    entry1.pack()
    entry1.place(x=w*0.3, y=h *0.35, anchor="nw", height=40, width=550)

    window.iconbitmap('book.ico')

    # wait for user to do something
    window.mainloop()
