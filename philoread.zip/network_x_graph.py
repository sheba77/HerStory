import networkx as nx
from networkx.readwrite import json_graph
import matplotlib.pyplot as plt
import os
import json
import sys
import re

from my_terms import my_terms
author_list = []


def make_list(my_string):
    word_list = set(re.split('[^a-zA-Z]', my_string))
    print("word_list : ")
    print(word_list)
    return word_list


def find_my_terms(data_list):
    """we look for the terms that our book has"""
    my_list = []
    data_list = make_list(data_list)
    for word in data_list:
        for term in my_terms:
            if word.endswith('ist'):
                word.replace('ist', 'ism')
            if term.lower() == word.lower():
                my_list.append(word)
    return my_list


def calculate_weight(G, node1, node2):
    if node1 and node2:
        phil_terms1 = set(nx.get_node_attributes(G, 'philosophy_terms')[node1])
        phil_terms2 = set(nx.get_node_attributes(G, 'philosophy_terms')[node2])
        aut_terms1 = set(nx.get_node_attributes(G, 'author_terms')[node1])
        aut_terms2 = set(nx.get_node_attributes(G, 'author_terms')[node2])
        best_terms1 = set(nx.get_node_attributes(G, 'best_term')[node1])
        best_terms2 = set(nx.get_node_attributes(G, 'best_term')[node2])

        is_author = heuristic_author_search(G, node1, node2)
        author_score = 0 if is_author else len(aut_terms1.difference(aut_terms2))

        return ((len(phil_terms1.difference(phil_terms2))*3) + author_score*5 +
                (len(best_terms1.difference(best_terms2))*10))
    else:
        return sys.maxsize

def precalculate_author_info(g):
    for node in g.nodes:
        my_author_data = [x for x in set(re.split('[^a-zA-Z]', g.node[node]['author_string'])) if x]
        other_authors_in_summary = []
        for item in my_author_data:
            for author in author_list:
                if item.lower() in author.lower():
                    other_authors_in_summary.append(author.lower())
        g.node[node]['other_authors_in_summary'] = set(other_authors_in_summary)

def heuristic_author_search(G, node1, node2):
    return len(G.node[node1]['other_authors_in_summary'] & G.node[node2]['other_authors_in_summary']) > 0

def get_intro_names(path):
    files = []
    my_book_names=[]
    # r=root, d=directories, f = files
    for r, d, f in os.walk(path):
        for file in f:
            if '.json' in file:
                files.append(os.path.join(r, file))

    for file in files:
        with open(file, "r") as read_file:
            data = json.load(read_file)
            my_books = data["book name"]
            my_book_names.append(my_books)
    return my_book_names


def make_nodes(g, path):
    files = []
    # r=root, d=directories, f = files
    for r, d, f in os.walk(path):
        for file in f:
            if '.json' in file:
                files.append(os.path.join(r, file))

    for file in files:
        with open(file, "r") as read_file:
            data = json.load(read_file)
            my_books = data["book name"]
            author = data["author name"]
            author_list.append(data["author name"])
            phi_terms = set(find_my_terms(data["book data"]))
            aut_terms = set(find_my_terms(data["author data"]))
            aut_string = data["author data"]
            g.add_node(my_books, author=author, philosophy_terms=phi_terms, author_terms=aut_terms,
                       author_string=aut_string, best_term=phi_terms & aut_terms)


def add_edges(g):
    for node1 in g.nodes:
        for node2 in g.nodes:
            g.add_edge(node1, node2, weight=calculate_weight(g, node1, node2))


def find_introbook(g, book_name):
    # TODO what to do if book is intructory
    weight_list = []
    book_names = get_intro_names(r"bigData\smalldata")
    for node_name in list(g.nodes):
        if node_name in book_names:
            if node_name == book_name:
                return node_name
            else:
                weight_list.append((node_name, g[book_name][node_name]['weight']))
        else:
            pass
    sorted(weight_list, key=lambda x:x[1])
    return weight_list[0][0]


def find_syllabus(book):
    my_graph = load_func()
    intro_node = find_introbook(my_graph, book)
    if intro_node == book:
        return [intro_node]
    else:
        dijkstra = nx.shortest_path(my_graph, intro_node, book, weight='weight', method='dijkstra')
        return dijkstra


# find_syllabus('Buffy the Vampire Slayer and Philosophy: Fear and Trembling in Sunnydale')


def make_all():
    g = nx.Graph()
    make_nodes(g, r"bigData\data")
    precalculate_author_info(g)
    for node1 in g.nodes:
        print(node1)
        for node2 in g.nodes:
            if node1 != node2:
                g.add_edge(node1, node2, weight=calculate_weight(g, node1, node2))
    m = nx.Graph()
    for node1, node2 in g.edges:
        m.add_edge(node1, node2, weight=g.get_edge_data(node1, node2)['weight'])
    # pos = nx.spring_layout(g)
    # nx.draw_networkx_nodes(g, pos, node_size=30)
    # nx.draw_networkx_edges(g, pos, width=1)
    # nx.draw_networkx_labels(g, pos, font_size=5, font_family='sans-serif')
    # plt.axis('off')
    # plt.show()

    data = json_graph.adjacency_data(m)
    with open('final_graph.json', 'w') as write_file:
        json.dump(data, write_file)

def load_func():
    with open('final_graph.json', 'r') as read_file:
        data = json.load(read_file)
        h = json_graph.adjacency_graph(data)
        return h
